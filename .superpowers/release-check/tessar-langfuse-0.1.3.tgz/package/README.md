# @tessar/langfuse

Optional Langfuse tracing for Tessar, using the official Langfuse SDK and
OpenTelemetry. Requires Node 24.14 or newer. Langfuse Cloud and self-hosted
Langfuse use the same configuration; choose the appropriate `baseUrl`.

```sh
npm install @tessar/core @tessar/langfuse
```

```ts
import { LangfusePlugin } from "@tessar/langfuse";

const tracing = new LangfusePlugin({
  publicKey: process.env.LANGFUSE_PUBLIC_KEY,
  secretKey: process.env.LANGFUSE_SECRET_KEY,
  baseUrl: process.env.LANGFUSE_BASE_URL,
});
// new Controller({ id, agent, plugins: [tracing] })
// await controller.initialize();
// Execute agent.stream()/generate() or work through a Session.
// await controller.dispose(); // Closes observations and flushes buffered exports.
```

All options are optional and otherwise use the official SDK's environment/default
settings. `baseUrl` selects a Cloud region or your deployment. This integration
uses Langfuse JS SDK v6, which requires self-hosted Langfuse v4.59.0 or newer;
see [Langfuse compatibility](https://langfuse.com/docs/observability/sdk/overview).

Each Stream is a trace containing agent, turn, generation and tool observations.
Generation observations include the effective model request, final response,
reported usage and errors. Requests include instructions, history, tool schemas
and configured model options. Auxiliary model calls made through the plugin API
are also captured and nested under their originating tool when applicable.

Observations retain Tessar's controller, agent, Session, Thread and Stream IDs,
along with scope metadata. When present, Tessar's Session ID is also the Langfuse
session ID. No user-ID field is inferred from application-defined scope keys.
Retries produce separate generations. Concurrent executions use explicit parents
and an instance-local tracer; the global application tracer is not replaced.

Suspension ends the active observation segment. Resume/recovery creates a new
segment with the same trace ID, derived from the existing logical execution IDs.
Durable runtime restart still requires a Tessar storage backend. Telemetry export
is buffered and best-effort; it is not a durable event journal.

Token details use exclusive buckets for ordinary input/output, cache reads,
cache writes and reasoning, avoiding double-counting inclusive provider totals.
Unknown counts are omitted rather than emitted as zero. The complete original
usage, including provenance and provider details, is retained in metadata.
Provider/model pricing is managed by Langfuse; Tessar does not invent costs.

No network request is awaited by an execution hook. The official span processor
batches exports in the background; Controller cleanup awaits its shutdown/flush.
Use the [developer guide](../../examples/guide/langfuse.md) for a complete example.
